import React, { useEffect, useState } from "react";

function App() {
  const [countries, setCountries] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [neighbors, setNeighbors] = useState([]);

  useEffect(() => {
    fetchCountries();
  }, []);

  useEffect(() => {
    if (countries.length > 0) {
      fetchNeighbors();
    }
  }, [countries]);

  useEffect(() => {
    console.log(neighbors);
  }, [neighbors]);

  const fetchCountries = async () => {
    setIsLoading(true);

    try {
      await fetch("https://travelbriefing.org/countries.json")
        .then((response) => response.json())
        .then((response) => {
          const countriesLength = response.length;

          for (let i = 0; i < 10; i++) {
            let index = Math.floor(Math.random() * countriesLength);
            const country = response[index];

            setCountries((prevState) => {
              return [...prevState, country];
            });
          }
        });
    } catch (error) {
      console.log(error.message);
    }
  };

  const fetchNeighbors = async () => {
    countries.map(async (country) => {
      await fetch(`https://travelbriefing.org/${country?.name}?format=json`)
        .then((response) => response.json())
        .then((response) => {
          setNeighbors((prevState) => {
            return [...prevState, response.neighbors];
          });
        })
        .finally(() => {
          setIsLoading(false);
        });
    });
  };

  if (isLoading) {
    return (
      <div className="App" style={{ padding: 20 }}>
        Loading...
      </div>
    );
  }

  if (!isLoading) {
    return (
      <div className="App" style={{ padding: 20 }}>
        {countries.map((country, index) => {
          return (
            <div onClick={() => country?.name} key={index.toString()}>
              <h6>{country?.name}</h6>
            </div>
          );
        })}

        {neighbors.map((neighbor, index) => {
          return <p key={index.toString()}>{neighbor.name}</p>;
        })}
      </div>
    );
  }
}
export default App;
